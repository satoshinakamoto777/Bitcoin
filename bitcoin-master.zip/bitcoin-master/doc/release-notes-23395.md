Notable changes
===============

New settings
------------

- The `shutdownnotify` option is used to specify a command to execute synchronously
before Bitcoin Core has begun its shutdown sequence. (#23395)
