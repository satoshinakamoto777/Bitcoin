RPC Wallet
----------

- RPC `unloadwallet` now fails if a rescan is in progress. (#26618)
