Updated RPCs
--------

The `minconf` option, which allows a user to specify the minimum number
of confirmations a UTXO being spent has, and the `maxconf` option,
which allows specifying the maximum number of confirmations, have been
added to the following RPCs:
- `fundrawtransaction`
- `send`
- `walletcreatefundedpsbt`
- `sendall`
